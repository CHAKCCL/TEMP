//
//  TouchIDUtil.h
//  BEA
//
//  Created by liukhai on 16/7/12.
//  Copyright © 2016年 The Bank of East Asia, Limited. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KeyChainManager.h"
#import "OpenUDID.h"
#import "RSAManager.h"

#define PubLicKeyB @"PubLicKeyB_In_KeyChain"

#define kTouchIDRequestTimeOut 990990

#define kTouchIDEnable 990071
#define kTouchIDNotYetEnable 990072
#define kIncorrectUIDPWD 990073
#define kTouchIDRegOverride 990081
#define kTouchIDLoginOverride 990082

#define kRegAuthenticationFailed 9900911
#define kLogAuthenticationFailed 9900912
#define kUserCancel 990092
#define kUserFallback 990093
#define kSystemCancel 990094
#define kPasscodeNotSet 990095
#define kTouchIDNotAvailable 990096
#define kTouchIDRegNotEnrolled 990097
#define kTouchIDLogNotEnrolled 990098
#define kTouchIDRegLockout 9900991
#define kTouchIDLogLockout 9900992

@interface TouchIDUtil : NSObject

@property (nonatomic, copy) NSString *remindStatus;

@property (nonatomic, copy) NSString *isRegistered;

@property (nonatomic, copy) NSString *registerAction;

@property (nonatomic, copy) NSString *UDID;

@property (nonatomic, copy) NSString *challenge;

@property (nonatomic, copy) NSString *loadURL;

@property (nonatomic, copy) NSString *jsonDataSources;

+ (TouchIDUtil *)me;

- (NSInteger)canEvaluatePolicy;

- (NSString *)getSHA256String:(NSString *)srcString;

- (NSString *)getTouchIDStatus;

- (void)setTouchIDStatusWith:(NSString *)value;

- (BOOL)checkDeviceFilesSupportTouchIDLogin;

+ (NSString *)getDocConfigSettingFilePath;

+ (NSString*)deviceModelName;

+ (BOOL)deviceModelSoupport;

@end
