//
//  KeyChainManager.h
//  FSPlatformDemo
//
//  Created by lkh on 16/4/8.
//  Copyright © 2016年 FSPlatformDemo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KeyChainManager : NSObject

+ (KeyChainManager *)me;

- (void)savePassWord:(NSString *)password;

- (id)readPassWord;

- (void)deletePassWord;

@end
