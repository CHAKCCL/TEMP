//
//  TouchIDUtil.m
//  BEA
//
//  Created by liukhai on 16/7/12.
//  Copyright © 2016年 The Bank of East Asia, Limited. All rights reserved.
//

#include <CommonCrypto/CommonDigest.h>
#import "TouchIDUtil.h"
#import "KeyChainManager.h"
#import "CoreData.h"
#import <sys/utsname.h>
#import "NSString+Contains.h"


@import LocalAuthentication;

@interface TouchIDUtil () <UIAlertViewDelegate, NSXMLParserDelegate, ASIHTTPRequestDelegate>

@end

@implementation TouchIDUtil

static TouchIDUtil *me;

+ (TouchIDUtil *)me {
    if (!me) {
        me = [[TouchIDUtil alloc] init];
        [TouchIDUtil copyConfigSettingFile];
    }
    return me;
}

- (NSInteger)canEvaluatePolicy {
    LAContext *context = [[LAContext alloc] init];
    NSString *message;
    NSError *error;
    BOOL success;
    NSInteger status;
    
    // test if we can evaluate the policy, this test will tell us if Touch ID is available and enrolled
    success = [context canEvaluatePolicy: LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error];
    //    NSData *data = context.evaluatedPolicyDomainState;
    if (success) {
        message = [NSString stringWithFormat:@"Touch ID is available"];
        status = 0;
    }
    else {
        message = [NSString stringWithFormat:@"Touch ID is not available, %@", error.localizedDescription];
        status = error.code;
    }
    
    NSLog(@"%@, error code = %ld", message, (long)error.code);
    return status;
}

//- (void)evaluatePolicy {
//    LAContext *context = [[LAContext alloc] init];
//    __block  NSString *message;
//    
//    // Show the authentication UI with our reason string.
//    [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:@"Unlock access to locked feature" reply:^(BOOL success, NSError *authenticationError) {
//        if (success) {
//            message = @"evaluatePolicy: succes";
//            
//            if ([self.registerAction isEqualToString:@"Register"]) {
//                [self generateKeyPairInDevice];
//            }
//            
//        }
//        else {
//            message = [NSString stringWithFormat:@"evaluatePolicy: %@", authenticationError.localizedDescription];
//        }
//        
//        switch (authenticationError.code) {
//            case LAErrorAuthenticationFailed:
//                NSLog(@"授权失败");
//                break;
//            case LAErrorUserCancel:
//                NSLog(@"用户取消验证");
//                break;
//            case LAErrorUserFallback:
//                NSLog(@"用户选择输入密码，切换主线程处理");
//                break;
//            case LAErrorSystemCancel :
//                NSLog(@"系统取消授权(例如其他APP切入) ");
//                break;
//            case LAErrorPasscodeNotSet:
//                NSLog(@"系统未设置密码");
//                break;
//            case LAErrorTouchIDNotAvailable:
//                NSLog(@"设备Touch ID不可用，例如未打开");
//                break;
//            case LAErrorTouchIDNotEnrolled:
//                NSLog(@"设备Touch ID不可用，用户未录入");
//                break;
//            default:
//                break;
//        }
//        
//        NSLog(@"%@", message);
//        
//    }];
//    
//}

#pragma mark - soupport

- (BOOL)checkDeviceFilesSupportTouchIDLogin {
    BOOL hasPubkey = false;
    BOOL hasKeyChain = false;
    
    NSString *status = [[TouchIDUtil me] getTouchIDStatus];
    if ([status isEqualToString:@"1"]) {
        return false;
    }
    
    NSString *setStatus = [[NSUserDefaults standardUserDefaults] valueForKey:@"Touch_ID_Remind_Status"];
    if (!setStatus || [setStatus isEqualToString:@"Never"] || [setStatus isEqualToString:@"Remind"]) {
        return false;
    }
    
    SecKeyRef pubKeyB = [RSAManager publicKeyWithPeerName:PubLicKeyB];
    if (pubKeyB) {
        hasPubkey = true;
    }
    
    NSString *keyChain = [[KeyChainManager me] readPassWord];
    if (keyChain) {
        hasKeyChain = true;
    }
    
    if (hasKeyChain && hasPubkey) {
        NSLog(@"have publicekeyB and DAN.");
        return true;
    } else {
        NSLog(@"less publickeyB or DAN.");
        return false;
    }
}

- (NSString *)getSHA256String:(NSString *)srcString {
    
    const char *cstr = [srcString cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:srcString.length];
    
    uint8_t digest[CC_SHA256_DIGEST_LENGTH];
    
    CC_SHA256(data.bytes, (int)data.length, digest);
    
    NSMutableString *result = [NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_SHA256_DIGEST_LENGTH; i++) {
        [result appendFormat:@"%02x", digest[i]];
    }
    
    return result;
}

- (id)findParameterWith:(NSString *)subSting inUrl:(NSString *)urlString {
    NSString *filename = subSting;
    NSString *escapedPath = urlString;
    
    NSLog(@"urlString = %@", escapedPath);
    
    NSRange iStart = [escapedPath rangeOfString:filename options:NSCaseInsensitiveSearch];
    
    if (iStart.length > 0){
        NSString *extension = [escapedPath substringFromIndex:iStart.location+iStart.length+1];
        NSLog(@"extension:%@",extension);
        
        NSRange range = [extension rangeOfString:@"json=" options:NSCaseInsensitiveSearch];
        extension = [extension substringFromIndex:range.length];
        
        NSString *jsonString = [extension stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSLog(@"%@", jsonString);
        NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        NSError *error = nil;
        NSJSONSerialization *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
        NSLog(@"error:%@\n JSON class is: %@\nJSON:\n%@", error, json.class, json);
        
        return json;
    }
    return nil;
}

- (NSString *)dirDoc {
    //[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSLog(@"app_home_doc: %@",documentsDirectory);
    return documentsDirectory;
}

- (void)createDir {
    NSString *documentsPath = [self dirDoc];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *testDirectory = [documentsPath stringByAppendingPathComponent:@"pubKey"];
    
    BOOL res= [fileManager createDirectoryAtPath:testDirectory withIntermediateDirectories:YES attributes:nil error:nil];
    if (res) {
        NSLog(@"文件夹创建成功");
    } else {
        NSLog(@"文件夹创建失败");
    }
}

- (void)createFile {
    NSString *documentsPath =[self dirDoc];
    NSString *testDirectory = [documentsPath stringByAppendingPathComponent:@"pubKey"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *testPath = [testDirectory stringByAppendingPathComponent:@"publicKeyB.txt"];
    BOOL res = [fileManager createFileAtPath:testPath contents:nil attributes:nil];
    if (res) {
        NSLog(@"文件创建成功: %@" ,testPath);
    } else {
        NSLog(@"文件创建失败");
    }
}

- (void)writeFileWith:(NSString *)files {
    NSString *documentsPath =[self dirDoc];
    NSString *testDirectory = [documentsPath stringByAppendingPathComponent:@"pubKey"];
    NSString *testPath = [testDirectory stringByAppendingPathComponent:@"publicKeyB.txt"];
    NSString *content= files;
    BOOL res = [content writeToFile:testPath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    if (res) {
        NSLog(@"文件写入成功");
    } else {
        NSLog(@"文件写入失败");
    }
}

- (NSString *)readFile {
    NSString *documentsPath = [self dirDoc];
    NSString *testDirectory = [documentsPath stringByAppendingPathComponent:@"pubKey"];
    NSString *testPath = [testDirectory stringByAppendingPathComponent:@"publicKeyB.txt"];
    
    NSString *content = [NSString stringWithContentsOfFile:testPath encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"文件读取成功: %@",content);
    return content;
}

- (void)fileAttriutes {
    NSString *documentsPath = [self dirDoc];
    NSString *testDirectory = [documentsPath stringByAppendingPathComponent:@"pubKey"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *testPath = [testDirectory stringByAppendingPathComponent:@"publicKeyB.txt"];
    NSDictionary *fileAttributes = [fileManager attributesOfItemAtPath:testPath error:nil];
    NSArray *keys;
    id key, value;
    keys = [fileAttributes allKeys];
    NSInteger count = keys.count;
    for (int i = 0; i < count; i++)
    {
        key = keys[i];
        value = [fileAttributes objectForKey:key];
        NSLog (@"Key: %@ for value: %@", key, value);
    }
}

- (void)deleteFile {
    NSString *documentsPath =[self dirDoc];
    NSString *testDirectory = [documentsPath stringByAppendingPathComponent:@"pubKey"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *testPath = [testDirectory stringByAppendingPathComponent:@"publicKeyB.txt"];
    BOOL res = [fileManager removeItemAtPath:testPath error:nil];
    if (res) {
        NSLog(@"文件删除成功");
    } else {
        NSLog(@"文件删除失败");
    }
    
    NSLog(@"文件是否存在: %@",[fileManager isExecutableFileAtPath:testPath]?@"YES":@"NO");
}

#pragma mark - Touch ID status

- (NSString *)getTouchIDStatus {
    NSMutableDictionary *user_setting = [NSMutableDictionary dictionaryWithContentsOfFile:[TouchIDUtil getDocConfigSettingFilePath]];
    NSString *status = [user_setting objectForKey:@"TouchIDStatus"];
    if (!status) {
        status = @"1";
    }
    NSString *setStatus = [[NSUserDefaults standardUserDefaults] valueForKey:@"Touch_ID_Remind_Status"];
    if ([setStatus isEqualToString:@"Never"]) {
        status = @"1";
    }
    
    return status;
}

- (void)setTouchIDStatusWith:(NSString *)value {
    NSMutableDictionary *setting = [NSMutableDictionary dictionaryWithContentsOfFile:[TouchIDUtil getDocConfigSettingFilePath]];
    
    NSLog(@"setting = %@", setting);
    
    [setting setObject:value forKey:@"TouchIDStatus"];
    [setting writeToFile:[TouchIDUtil getDocConfigSettingFilePath] atomically:YES];
    NSLog(@"setting = %@", setting);
    
    if ([value isEqualToString:@"1"]) {
        SecKeyRef publicKeyB = [RSAManager publicKeyWithPeerName:PubLicKeyB];
        if (publicKeyB) {
            [RSAManager removePublicKeyWith:PubLicKeyB];
        }
    }
}

+ (void)copyConfigSettingFile {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *newFilePath = [documentsDirectory stringByAppendingPathComponent:@"TouchIDConfigSetting.plist"];
    NSString *oldfilePath = [[NSBundle mainBundle] pathForResource:@"TouchIDConfigSetting" ofType:@"plist"];
    
    [[NSFileManager defaultManager] copyItemAtPath:oldfilePath
                                            toPath:newFilePath
                                             error:NULL];
    if ([[NSFileManager defaultManager] fileExistsAtPath:newFilePath]){
        NSLog(@"copyTouchIDConfigSettingFile created:%@", newFilePath);
    }else {
        NSLog(@"copyTouchIDConfigSettingFile fail:%@", newFilePath);
    }
}

+ (NSString *)getDocConfigSettingFilePath {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"TouchIDConfigSetting.plist"];
    return filePath;
}

+ (NSString*)deviceModelName {
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceModel = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    
    //iPhone 系列
    if ([deviceModel isEqualToString:@"iPhone1,1"])    return @"iPhone 1G";
    if ([deviceModel isEqualToString:@"iPhone1,2"])    return @"iPhone 3G";
    if ([deviceModel isEqualToString:@"iPhone2,1"])    return @"iPhone 3GS";
    if ([deviceModel isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    if ([deviceModel isEqualToString:@"iPhone3,2"])    return @"Verizon iPhone 4";
    if ([deviceModel isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    if ([deviceModel isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
    if ([deviceModel isEqualToString:@"iPhone5,2"])    return @"iPhone 5";
    if ([deviceModel isEqualToString:@"iPhone5,3"])    return @"iPhone 5C";
    if ([deviceModel isEqualToString:@"iPhone5,4"])    return @"iPhone 5C";
    if ([deviceModel isEqualToString:@"iPhone6,1"])    return @"iPhone 5S";
    if ([deviceModel isEqualToString:@"iPhone6,2"])    return @"iPhone 5S";
    if ([deviceModel isEqualToString:@"iPhone7,1"])    return @"iPhone 6 Plus";
    if ([deviceModel isEqualToString:@"iPhone7,2"])    return @"iPhone 6";
    if ([deviceModel isEqualToString:@"iPhone8,1"])    return @"iPhone 6s";
    if ([deviceModel isEqualToString:@"iPhone8,2"])    return @"iPhone 6s Plus";
    if ([deviceModel isEqualToString:@"iPhone8,4"])    return @"iPhone SE";
    if ([deviceModel isEqualToString:@"iPhone9,1"])    return @"iPhone 7";
    if ([deviceModel isEqualToString:@"iPhone9,2"])    return @"iPhone 7 Plus";
    
    //iPod 系列
    if ([deviceModel isEqualToString:@"iPod1,1"])      return @"iPod Touch 1G";
    if ([deviceModel isEqualToString:@"iPod2,1"])      return @"iPod Touch 2G";
    if ([deviceModel isEqualToString:@"iPod3,1"])      return @"iPod Touch 3G";
    if ([deviceModel isEqualToString:@"iPod4,1"])      return @"iPod Touch 4G";
    if ([deviceModel isEqualToString:@"iPod5,1"])      return @"iPod Touch 5G";
    
    //iPad 系列
    if ([deviceModel isEqualToString:@"iPad1,1"])      return @"iPad";
    if ([deviceModel isEqualToString:@"iPad2,1"])      return @"iPad 2 (WiFi)";
    if ([deviceModel isEqualToString:@"iPad2,2"])      return @"iPad 2 (GSM)";
    if ([deviceModel isEqualToString:@"iPad2,3"])      return @"iPad 2 (CDMA)";
    if ([deviceModel isEqualToString:@"iPad2,4"])      return @"iPad 2 (32nm)";
    if ([deviceModel isEqualToString:@"iPad2,5"])      return @"iPad mini (WiFi)";
    if ([deviceModel isEqualToString:@"iPad2,6"])      return @"iPad mini (GSM)";
    if ([deviceModel isEqualToString:@"iPad2,7"])      return @"iPad mini (CDMA)";
    
    if ([deviceModel isEqualToString:@"iPad3,1"])      return @"iPad 3(WiFi)";
    if ([deviceModel isEqualToString:@"iPad3,2"])      return @"iPad 3(CDMA)";
    if ([deviceModel isEqualToString:@"iPad3,3"])      return @"iPad 3(4G)";
    if ([deviceModel isEqualToString:@"iPad3,4"])      return @"iPad 4 (WiFi)";
    if ([deviceModel isEqualToString:@"iPad3,5"])      return @"iPad 4 (4G)";
    if ([deviceModel isEqualToString:@"iPad3,6"])      return @"iPad 4 (CDMA)";
    
    if ([deviceModel isEqualToString:@"iPad4,1"])      return @"iPad Air";
    if ([deviceModel isEqualToString:@"iPad4,2"])      return @"iPad Air";
    if ([deviceModel isEqualToString:@"iPad4,3"])      return @"iPad Air";
    if ([deviceModel isEqualToString:@"iPad5,3"])      return @"iPad Air 2";
    if ([deviceModel isEqualToString:@"iPad5,4"])      return @"iPad Air 2";
    if ([deviceModel isEqualToString:@"i386"])         return @"Simulator";
    if ([deviceModel isEqualToString:@"x86_64"])       return @"Simulator";
    
    if ([deviceModel isEqualToString:@"iPad6,7"])      return @"iPad Pro";
    if ([deviceModel isEqualToString:@"iPad6,8"])      return @"iPad Pro";
    
    if ([deviceModel isEqualToString:@"iPad4,4"]
        ||[deviceModel isEqualToString:@"iPad4,5"]
        ||[deviceModel isEqualToString:@"iPad4,6"])      return @"iPad mini 2";
    
    if ([deviceModel isEqualToString:@"iPad4,7"]
        ||[deviceModel isEqualToString:@"iPad4,8"]
        ||[deviceModel isEqualToString:@"iPad4,9"])      return @"iPad mini 3";
    
    if ([deviceModel isEqualToString:@"iPad5,1"]
        ||[deviceModel isEqualToString:@"iPad5,2"])      return @"iPad mini 4";
    
    return deviceModel;
}


+ (BOOL)deviceModelSoupport {
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceModel = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    
    if ([deviceModel myContainsString:@"iPhone"]) {
        if ([deviceModel isEqualToString:@"iPhone1,1"] ||
            [deviceModel isEqualToString:@"iPhone1,2"] ||
            [deviceModel isEqualToString:@"iPhone2,1"] ||
            [deviceModel isEqualToString:@"iPhone3,1"] ||
            [deviceModel isEqualToString:@"iPhone3,2"] ||
            [deviceModel isEqualToString:@"iPhone4,1"] ||
            [deviceModel isEqualToString:@"iPhone5,1"] ||
            [deviceModel isEqualToString:@"iPhone5,2"] ||
            [deviceModel isEqualToString:@"iPhone5,3"] ||
            [deviceModel isEqualToString:@"iPhone5,4"]
            ) {
            return false;
        } else {
            return true;
        }
    } else if ([deviceModel myContainsString:@"iPad"]) {
        if ([deviceModel isEqualToString:@"iPad1,1"] ||
            [deviceModel isEqualToString:@"iPad2,1"] ||
            [deviceModel isEqualToString:@"iPad2,2"] ||
            [deviceModel isEqualToString:@"iPad2,3"] ||
            [deviceModel isEqualToString:@"iPad2,4"] ||
            [deviceModel isEqualToString:@"iPad2,5"] ||
            [deviceModel isEqualToString:@"iPad2,6"] ||
            [deviceModel isEqualToString:@"iPad2,7"] ||
            [deviceModel isEqualToString:@"iPad3,1"] ||
            [deviceModel isEqualToString:@"iPad3,2"] ||
            [deviceModel isEqualToString:@"iPad3,3"] ||
            [deviceModel isEqualToString:@"iPad3,4"] ||
            [deviceModel isEqualToString:@"iPad3,5"] ||
            [deviceModel isEqualToString:@"iPad3,6"] ||
            [deviceModel isEqualToString:@"iPad4,1"] ||
            [deviceModel isEqualToString:@"iPad4,2"] ||
            [deviceModel isEqualToString:@"iPad4,3"] ||
            [deviceModel isEqualToString:@"iPad4,4"] ||
            [deviceModel isEqualToString:@"iPad4,5"] ||
            [deviceModel isEqualToString:@"iPad4,6"]
            ) {
            return false;
        } else {
            return true;
        }
    } else {
        return false;
    }
}

@end
