//
//  NSData+HexString.h
//  SecKeyWrapper
//
//  Created by qwer on 16/8/5.
//  Copyright © 2016年 zhanhongjin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (HexString)

//16进制转data
+(id)dataWithHexString:(NSString *)hex;
    
//data转换为十六进制的
+ (NSString *)hexStringFromData:(NSData*)data;
    
@end
