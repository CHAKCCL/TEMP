//
//  RSAManager.h
//  SecKeyWrapper
//
//  Created by zhanhongjin on 16/8/8.
//  Copyright © 2016年 formssi. All rights reserved.
//


/**
 *  说明
 *
 *  导入第三方库：GTMBase64，这是比较常用的第三方库，有些项目可能已经有这个库了，需要注意一下不要重复导入
 *  不同项目请修改SecKeyWrapper文件的kPublicKeyTag和kPrivateKeyTag参数，以免重复
 *  SecKeyWrapper是官方提供的类，非ARC，需要去TARGETS、Bulid Phases设置SecKeyWrapper.m类为： -fno-objc-arc
 *  生成Key只适用真机，模拟器无法生成
 */

#import <Foundation/Foundation.h>
#import "SecKeyWrapper.h"
#import "GTMBase64.h"   //需要Base64编码支持，有些项目可能本身已经有这个库了，导入时注意一下


//#define PublicKeyTag @""

@interface RSAManager : NSObject

/**
 *  生成一对公钥密钥并保存到keychain，每次调用会生成一对新的并把旧的删除
 */
+ (void)generateKeyPair;

/**
 *  获取生成的公钥字符串，用base64编码转换
 *
 *  @return 公钥，base64编码，JAVA服务器适用
 */
+ (NSString *)publicKeyEncodingWithHexString;

/**
 *  保存公钥到本机keychain,并返回SecKeyRef
 *
 *  @param peerName  公钥tag
 *  @param hexString 公钥，十六进制字符串
 */
+ (SecKeyRef)savePublicKeyWithPeerName:(NSString *)peerName publicKey:(NSString *)hexString;


/**
 *  根据peerName获取公钥
 *
 *  @param peerName peerName
 *
 *  @return SecKeyRef
 */
+ (SecKeyRef)publicKeyWithPeerName:(NSString *)peerName;

+ (void)removePublicKeyWith:(NSString *)peerName;

//+ (SecKeyRef)privateKeyWithPeerName:(NSString *)peerName;

+ (SecKeyRef)defaultPublicKey;

+ (SecKeyRef)defaultPrivateKey;

+ (NSString *)encryptWithPublicKey:(SecKeyRef)key plainText:(NSString*)plainText;

+ (NSString *)decryptWithPrivateKey:(SecKeyRef)key cipherText:(NSString*)cipher;


@end
