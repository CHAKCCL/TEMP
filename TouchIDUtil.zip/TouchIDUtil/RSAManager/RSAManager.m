//
//  RSAManager.m
//  SecKeyWrapper
//
//  Created by qwer on 16/8/8.
//  Copyright © 2016年 zhanhongjin. All rights reserved.
//

#import "RSAManager.h"
#import <Security/Security.h>
#import "NSData+HexString.h"
//#import "Base64.h"
#include <stdlib.h>

const size_t BUFFER_SIZE = 2048;
const size_t CIPHER_BUFFER_SIZE = 2048;   //公钥密钥长度设置，可选2046，1024，512.需要跟服务器统一
const uint32_t PADDING = kSecPaddingPKCS1;  //加密参数，加密补全设置。需要跟服务器统一

@implementation RSAManager



/**
 *  生成一对公钥密钥并保存到keychain，每次调用会生成一对新的并把旧的删除
 */
+ (void)generateKeyPair {
    [[SecKeyWrapper sharedWrapper] generateKeyPair:CIPHER_BUFFER_SIZE];
}

/**
 *  获取生成的公钥字符串，用base64编码转换
 *
 *  @return 公钥，base64编码，JAVA服务器适用
 */
+ (NSString *)publicKeyEncodingWithHexString{
    NSData *data = [[SecKeyWrapper sharedWrapper] getPublicKeyBits];
    if (data == nil) {
        return @"";
    }
    NSMutableString *hexPublic = [[NSMutableString alloc] initWithString:[NSData hexStringFromData:data]];
    
    //根据密钥长度，加上不同head
    if (CIPHER_BUFFER_SIZE == 1024) {
        [hexPublic insertString:@"9f300d06092a864886f70d010101050003818d003081" atIndex:4];
    }else if (CIPHER_BUFFER_SIZE == 2048) {
        [hexPublic insertString:@"0122300d06092a864886f70d01010105000382010f003082" atIndex:4];
    }
    
    return hexPublic;
}


/**
 *  保存公钥到本机keychain,并返回SecKeyRef
 *
 *  @param peerName  公钥tag
 *  @param hexString 公钥，十六进制字符串
 */
+ (SecKeyRef)savePublicKeyWithPeerName:(NSString *)peerName publicKey:(NSString *)hexString{
    
    NSData *publickData = [NSData dataWithHexString:hexString];
    publickData = [self stripPublicKeyHeader:publickData];
    
    [self addPeerPublicKey:peerName keyBits:publickData];
    
    return [self getPublicKeyReference:peerName];
}

+ (void)removePublicKeyWith:(NSString *)peerName {
    [[SecKeyWrapper sharedWrapper] removePeerPublicKey:peerName];
}

+ (SecKeyRef)publicKeyWithPeerName:(NSString *)peerName{
    return [self getPublicKeyReference:peerName];
}


//+ (SecKeyRef)privateKeyWithPeerName:(NSString *)peerName{
//    return nil;
//}


+ (SecKeyRef)defaultPublicKey{
    return [[SecKeyWrapper sharedWrapper] getPublicKeyRef];
}


+ (SecKeyRef)defaultPrivateKey{
    return [[SecKeyWrapper sharedWrapper] getPrivateKeyRef];
}


+ (NSString *)encryptWithPublicKey:(SecKeyRef)key plainText:(NSString*)plainText{
    
    if (plainText.length > CIPHER_BUFFER_SIZE/8-11) {
        NSLog(@"Encrypt error:plainText too long");
        return @"";
    }
    
    uint8_t *plainBuffer;
    uint8_t *cipherBuffer;
    
    const char *inputString = [plainText cStringUsingEncoding:NSUTF8StringEncoding];
    long len = strlen(inputString);
//    NSLog(@"inputString[].lenge = %ld", len);
    // TODO: this is a hack since i know inputString length will be less than BUFFER_SIZE
    if (len > BUFFER_SIZE) {
        len = BUFFER_SIZE-1;
    }
    
    plainBuffer = (uint8_t *)calloc(BUFFER_SIZE, sizeof(uint8_t));
    cipherBuffer = (uint8_t *)calloc(CIPHER_BUFFER_SIZE, sizeof(uint8_t));
    
    strncpy( (char *)plainBuffer, inputString, len);
    NSString *base64String = @"";
    int length;
    if (CIPHER_BUFFER_SIZE == 1024) {
        length = 172;
    }else if (CIPHER_BUFFER_SIZE == 2048) {
        length = 344;
    }
    while (base64String == nil || base64String.length != length) {
        //现在有个问题是有时候加密出来cipherBuffer长度不对，
        //在2048位密钥的情况下:cipherBuffer正确的是256，转出来的base64String是344长度。
        //暂时方案是比较长度，不对的话重新生成一遍
        cipherBuffer = (uint8_t *)calloc(CIPHER_BUFFER_SIZE, sizeof(uint8_t));
        [self encryptWithPublicKey:key plainBuffer:(UInt8 *)plainBuffer cipherBuffer:cipherBuffer];
        size_t cipherBufferSize = strlen((char *)cipherBuffer);
        base64String = [GTMBase64 stringByEncodingBytes:cipherBuffer length:cipherBufferSize];
        
        
    }
//    NSLog(@"Base64密文:%@",base64String);

    
    free(plainBuffer);
    free(cipherBuffer);
    
    return base64String;


}


+ (NSString *)decryptWithPrivateKey:(SecKeyRef)key cipherText:(NSString*)cipher{

    NSString *result;
    uint8_t *decryptedBuffer;
    
    
    NSData *data = [GTMBase64 decodeString:cipher];
    
    const char *testString ;
    testString = [data bytes];
    
    char *bytes = malloc(sizeof(*bytes) * 256);
    char *bytes2 = malloc(sizeof(*bytes) * 256);
    for (int i=0;i<256;i++) {
        int byte = testString [i];
        bytes[i] = byte;
        bytes2[i] = byte;
        
    }

    
    decryptedBuffer = (uint8_t *)calloc(BUFFER_SIZE, sizeof(uint8_t));
    
    [self decryptWithPrivateKey:key cipherBuffer:bytes2 plainBuffer:decryptedBuffer];
    
    result = [[NSString alloc] initWithBytes:decryptedBuffer length:strlen((char *)decryptedBuffer) encoding:NSUTF8StringEncoding];
    
    free(decryptedBuffer);
    free(bytes2);
    
    

    
    return result;
}

/**
 *  加密
 *
 *  @param plainBuffer  明文
 *  @param cipherBuffer 密文
 */
+ (void)encryptWithPublicKey:(SecKeyRef)key plainBuffer:(uint8_t *)plainBuffer cipherBuffer:(uint8_t *)cipherBuffer {
    
    //    NSLog(@"== encryptWithPublicKey()");
    
    OSStatus status = noErr;
    
    //    NSLog(@"** original plain text 0: %s", plainBuffer);
    
    size_t plainBufferSize = strlen((char *)plainBuffer);
    size_t cipherBufferSize = CIPHER_BUFFER_SIZE;
    
    status = SecKeyEncrypt(key,
                           PADDING,
                           plainBuffer,
                           plainBufferSize,
                           &cipherBuffer[0],
                           &cipherBufferSize
                           );
//    NSLog(@"encrypted text: %s\n", cipherBuffer);
}


/**
 *  解密
 *
 *  @param cipherBuffer 密文
 *  @param plainBuffer  明文
 */
+ (void)decryptWithPrivateKey:(SecKeyRef)priVateKey cipherBuffer:(uint8_t *)cipherBuffer plainBuffer:(uint8_t *)plainBuffer {
    OSStatus status = noErr;
    
    size_t cipherBufferSize = 256;

    
    // DECRYPTION
    size_t plainBufferSize = BUFFER_SIZE;
    
    //  Error handling
    status = SecKeyDecrypt(priVateKey,
                           PADDING,
                           &cipherBuffer[0],
                           cipherBufferSize,
                           &plainBuffer[0],
                           &plainBufferSize
                           );
    NSLog(@"FINAL decrypted text: %s\n", plainBuffer);
    
}




+ (NSData *)stripPublicKeyHeader:(NSData *)d_key
{
    // Skip ASN.1 public key header
    if (d_key == nil) return(nil);
    
    unsigned int len = [d_key length];
    if (!len) return(nil);
    
    unsigned char *c_key = (unsigned char *)[d_key bytes];
    unsigned int  idx    = 0;
    
    if (c_key[idx++] != 0x30) {
        return(nil);
    }
    
    if (c_key[idx] > 0x80) idx += c_key[idx] - 0x80 + 1;
    else idx++;
    
    // PKCS #1 rsaEncryption szOID_RSA_RSA
    static unsigned char seqiod[] =
    { 0x30,   0x0d, 0x06, 0x09, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01,
        0x01, 0x05, 0x00 };
    if (memcmp(&c_key[idx], seqiod, 15)) return(nil);
    
    idx += 15;
    
    if (c_key[idx++] != 0x03) return(nil);
    
    if (c_key[idx] > 0x80) idx += c_key[idx] - 0x80 + 1;
    else idx++;
    
    if (c_key[idx++] != '\0') return(nil);
    
    // Now make a new NSData from this buffer
    return([NSData dataWithBytes:&c_key[idx] length:len - idx]);
    
}

/**
 *  将NSData转成密钥保存到keychain
 *
 *  @param peerName      peerName
 *  @param publicKeyData 公钥
 */
+ (void)addPeerPublicKey:(NSString *)peerName keyBits:(NSData *)publicKeyData {
    
    OSStatus sanityCheck = noErr;
    CFTypeRef persistPeer = NULL;
    [[SecKeyWrapper sharedWrapper] removePeerPublicKey:peerName];
    
    NSData * peerTag = [[NSData alloc] initWithBytes:(const void *)[peerName UTF8String] length:[peerName length]];
    NSMutableDictionary * peerPublicKeyAttr = [[NSMutableDictionary alloc] init];
    [peerPublicKeyAttr setObject:(id)kSecClassKey forKey:(id)kSecClass];
    [peerPublicKeyAttr setObject:(id)kSecAttrKeyTypeRSA forKey:(id)kSecAttrKeyType];
    [peerPublicKeyAttr setObject:peerTag forKey:(id)kSecAttrApplicationTag];
    [peerPublicKeyAttr setObject:publicKeyData forKey:(id)kSecValueData];
    [peerPublicKeyAttr setObject:[NSNumber numberWithBool:YES] forKey:(id)kSecReturnData];
    sanityCheck = SecItemAdd((CFDictionaryRef) peerPublicKeyAttr, (CFTypeRef *)&persistPeer);
    
    if(sanityCheck == errSecDuplicateItem){
        //        NSLog(@"Problem adding the peer public key to the keychain, OSStatus == %d.", (int)sanityCheck );
    }
    
    //    NSLog(@"SecItemAdd OSStATUS = %d", sanityCheck);
    
    //    NSLog(@"PersistPeer privatekey data after import into keychain %@", persistPeer);
    persistPeer = NULL;
    [peerPublicKeyAttr removeObjectForKey:(id)kSecValueData];
    sanityCheck = SecItemCopyMatching((CFDictionaryRef) peerPublicKeyAttr, (CFTypeRef*)&persistPeer);
    
    
    if (persistPeer) CFRelease(persistPeer);
}


/**
 *  从keychain读取密钥SeckeyRef值
 *
 *  @param peerName peerName
 *
 *  @return 密钥SeckeyRef
 */
+ (SecKeyRef)getPublicKeyReference:(NSString*)peerName{
    
    OSStatus sanityCheck = noErr;
    
    SecKeyRef pubKeyRefData = NULL;
    NSData * peerTag = [[NSData alloc] initWithBytes:(const void *)[peerName UTF8String] length:[peerName length]];
    NSMutableDictionary * peerPublicKeyAttr = [[NSMutableDictionary alloc] init];
    
    [peerPublicKeyAttr setObject:(id)kSecClassKey forKey:(id)kSecClass];
    [peerPublicKeyAttr setObject:(id)kSecAttrKeyTypeRSA forKey:(id)kSecAttrKeyType];
    [peerPublicKeyAttr setObject:peerTag forKey:(id)kSecAttrApplicationTag];
    [peerPublicKeyAttr setObject:[NSNumber numberWithBool:YES] forKey:       (id)kSecReturnRef];
    sanityCheck = SecItemCopyMatching((CFDictionaryRef) peerPublicKeyAttr, (CFTypeRef*)&pubKeyRefData);
    
    
    if(pubKeyRefData){
        //        NSLog(@"SecItem copy matching returned this publickeyref  %@", pubKeyRefData);
        return pubKeyRefData;
    }else{
        NSLog(@"pubKeyRef is NULL");
        return nil;
    }
}



@end
