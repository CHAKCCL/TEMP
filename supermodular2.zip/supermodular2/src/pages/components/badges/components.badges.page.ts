import { Component } from '@angular/core';

@Component({
	templateUrl: 'components.badges.html'
})

export class ComponentsBadgesPage {

}
