import { Component } from '@angular/core';


@Component({
	templateUrl: 'components.inputs.inset-labels.html'
})
export class ComponentsInputsInsetLabelsPage {
}
