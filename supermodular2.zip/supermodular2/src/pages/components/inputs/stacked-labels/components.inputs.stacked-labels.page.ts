import { Component } from '@angular/core';


@Component({
	templateUrl: 'components.inputs.stacked-labels.html'
})
export class ComponentsInputsStackedLabelsPage {

}
